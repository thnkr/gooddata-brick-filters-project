Gooddata Brick Filters Project
==============================

An example project for use with the the User Filters Brick Tutorial.
